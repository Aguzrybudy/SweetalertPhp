<!--
Created By : Aguzrybudy
Blog	   : Aguzrybudy.blogspot.co.id
time	   : Sunday, 17 April 2016
-->

<!DOCTYPE HTML>
<html lang="en"> 
<head>
<meta charset="utf-8">
<title>Aguzrybudy.com | Sweet Alert</title>
<link rel="stylesheet" href="alert/css/sweetalert.css">
</head>
<body >

	<form   method="post" id="email" action="subscribe_act.php">
		<p><input name="email" placeholder="Enter Your Email" type="text" id="inputemail">
		<input type="submit" value="Submit" ></p>
	</form>

<!--Scripts-->
<script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
<script src="alert/js/sweetalert.min.js"></script>
<script src="alert/js/qunit-1.18.0.js"></script>
</body>
</html>
